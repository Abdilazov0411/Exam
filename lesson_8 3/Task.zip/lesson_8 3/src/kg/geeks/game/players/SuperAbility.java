package kg.geeks.game.players;

public enum SuperAbility {
    HEAL,
    BOOST,
    CRITICAL_DAMAGE,
    BLOCK_DAMAGE_AND_REVERT,
    BONUS_DAMAGE
}
