package kg.geeks.game.players;

public interface HavingSuperAbility {
    void applySuperPower(Boss boss, Hero[] heroes);
}
